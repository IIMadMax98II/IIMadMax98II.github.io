#include "Visitor.h"
#include "Window.h"

void Window::accept(Visitor* ai)
{
	ai->updateDamageQuantity(this, -1);
	ai->updateSmallest(this, -1);
}
