#include "Players.h"

SelectiveGuesses::SelectiveGuesses()
{
	lastHit.setPos(0, 0);
	betterGuesses = {};
}

bool SelectiveGuesses::isEmpty()
{
	return betterGuesses.empty();
}

void SelectiveGuesses::setLastHit(Coordinates c)
{
	lastHit = c;
}

void SelectiveGuesses::addGuess(int x, int y)
{
	Coordinates tempCoord;
	tempCoord.setPos(x, y);
	betterGuesses.push_back(tempCoord);
}

Coordinates SelectiveGuesses::popGuess()
{
	Coordinates tempCoord = betterGuesses.back();
	betterGuesses.pop_back();

	return tempCoord;
	
}

void SelectiveGuesses::adaptGuesses(int currentGuess, Coordinates moves[])
{
	if (lastHit.getPosX() + 1 < 10)
	{
		int i = 0;
		bool isPlayed = false;

		while (i <= currentGuess)
		{
			if (moves[i].getPosX() == lastHit.getPosX() + 1 && moves[i].getPosY() == lastHit.getPosY())
			{
				isPlayed = true;
				break;
			}
			else
				i++;
		}

		if (!betterGuesses.empty())
		{
			for (int x = 0; x < betterGuesses.size(); x++)
			{
				if (betterGuesses[x].getPosX() == lastHit.getPosX() + 1 && betterGuesses[x].getPosY() == lastHit.getPosY())
				{
					isPlayed = true;
					break;
				}
			}
		}

		if (!isPlayed)
			addGuess(lastHit.getPosX() + 1, lastHit.getPosY());
	}

	if (lastHit.getPosX() - 1 >= 0)
	{
		int i = 0;
		bool isPlayed = false;

		while (i <= currentGuess)
		{
			if (moves[i].getPosX() == lastHit.getPosX() - 1 && moves[i].getPosY() == lastHit.getPosY())
			{
				isPlayed = true;
				break;
			}
			else
				i++;
		}

		if (!betterGuesses.empty())
		{
			for (int x = 0; x < betterGuesses.size(); x++)
			{
				if (betterGuesses[x].getPosX() == lastHit.getPosX() - 1 && betterGuesses[x].getPosY() == lastHit.getPosY())
				{
					isPlayed = true;
					break;
				}
			}
		}

		if (!isPlayed)
			addGuess(lastHit.getPosX() - 1, lastHit.getPosY());
	}

	if (lastHit.getPosY() + 1 < 10)
	{
		int i = 0;
		bool isPlayed = false;

		while (i <= currentGuess)
		{
			if (moves[i].getPosX() == lastHit.getPosX() && moves[i].getPosY() == lastHit.getPosY() + 1)
			{
				isPlayed = true;
				break;
			}
			else
				i++;
		}

		if (!betterGuesses.empty())
		{
			for (int x = 0; x < betterGuesses.size(); x++)
			{
				if (betterGuesses[x].getPosX() == lastHit.getPosX() && betterGuesses[x].getPosY() == lastHit.getPosY() + 1)
				{
					isPlayed = true;
					break;
				}
			}
		}

		if (!isPlayed)
			addGuess(lastHit.getPosX() , lastHit.getPosY() + 1);
	}

	if (lastHit.getPosY() - 1 >= 0)
	{
		int i = 0;
		bool isPlayed = false;

		while (i <= currentGuess)
		{
			if (moves[i].getPosX() == lastHit.getPosX() && moves[i].getPosY() == lastHit.getPosY() - 1)
			{
				isPlayed = true;
				break;
			}
			else
				i++;
		}

		if(!betterGuesses.empty())
		{
			for (int x = 0; x < betterGuesses.size(); x++)
			{
				if (betterGuesses[x].getPosX() == lastHit.getPosX() && betterGuesses[x].getPosY() == lastHit.getPosY() - 1)
				{
					isPlayed = true;
					break;
				}
			}
		}

		if (!isPlayed)
			addGuess(lastHit.getPosX() , lastHit.getPosY() - 1);
	}
}

/*
void SelectiveGuesses::adaptPreciseGuesses(int currentGuess, Coordinates moves[], int partsLeft)
{
	
	if (lastHit.getPosX() + 1 < 10)
	{
		int i = 0;
		bool isPlayed = false;

		while (i < currentGuess)
		{
			if (moves[i].getPosX() == lastHit.getPosX() + 1 && moves[i].getPosY() == lastHit.getPosY())
			{
				isPlayed = true;
				break;
			}
			else
				i++;
		}

		if (!isPlayed)
			addGuess(lastHit.getPosX() + 1, lastHit.getPosY());
	}
}
*/