#include "Props.h"
#include "Board.h"
#include "Players.h"

Ship::Ship(int l, int dir, int posX, int posY, Player* owner)
{
	this->length = l;
	this->totalDamage = 0;
	this->owner = owner;
	this->parts = new ShipPart [length];
	this->isDestroyed = false;

	for (int i = 0; i < length; i++)
	{
		if (dir == 0)
			parts[i].place(posX, posY + i, owner->getPlayArea());
		else
			parts[i].place(posX + i, posY, owner->getPlayArea());
			
	}
}

int Ship::getTotalDamage()
{
	for (int i = 0; i < length; i++)
	{
		if (!parts[i].giveStatus())
			totalDamage++;
	}

	return totalDamage;
}

bool Ship::getIsDestroyed()
{
	int damaged = 0;

	for (int i = 0; i < length; i++)
	{
		if (!parts[i].giveStatus())
			damaged++;
	}

	if (damaged == length)
		isDestroyed = true;

	return isDestroyed;
}

int Ship::getLength()
{
	return length;
}

ShipPart::ShipPart()
{
	isFunctional = true;
	id = PropsType::SHIP;
}

bool ShipPart::giveStatus()
{
	return isFunctional;
}

void ShipPart::setStatus(bool status)
{
	isFunctional = status;
}

PropsType ShipPart::hit(PlayZone& enemBoard)
{
	std::cout << "TARGET HIT!!!\n";
	setStatus(false);
	return id;
}