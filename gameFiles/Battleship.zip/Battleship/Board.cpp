#include "Board.h"

PlayZone::PlayZone()
{
	for (int x = 0; x < 10; x++)
	{
		for (int y = 0; y < 10; y++)
		{
			board[x][y] = new Water(x,y);
		}
	}
}

PropsType PlayZone::getPropId(int x, int y)
{
	return board[y][x]->getId(); 
}

void PlayZone::changeProp(int x, int y ,Props* newProp)
{
	board[y][x] = newProp;
}

Props* PlayZone::getProp(int x, int y)
{
	return board[y][x];
}