#include "Players.h"

void whitespaceCleaner(std::string& input)
{
	if (!input.empty())
	{
		int count = 0;
			int i = 0;
			while (input[i++] == ' ') { count++; }
		input.erase(0, count);
			i = input.length() - 1;
			count = 0;
			while (input[i--] == ' ') { count++; }
		input.erase(input.length() - count, count);
	}
}

User::User()
{
	name = "Default";
}

User::~User()
{
	for (int i = 0; i < 5; i++)
	{
		delete mines[i];
		delete ships[i];
	}

}

void User::setName()
{
	std::cout << "Please state your name: ";
	getValidName(name);
	if (name == "")
	{
		name = "Default";
	}
	std::cout << "Welcome " << name << std::endl;
}

std::string User::getName()
{
	return name;
}

void User::accept(Visitor* ai)
{
	int length = getSmallestShip();
	int damage = getDamageQuantity(length);

	ai->updateSmallest(this, length);
	ai->updateDamageQuantity(this, damage);
}

bool User::getValidName(std::string& name)
{
	std::string inputLine;
	std::getline(std::cin, inputLine);

	whitespaceCleaner(inputLine);

	std::stringstream inputStream(inputLine);

	bool fail1 = (inputStream >> name).fail();
	bool fail2 = inputStream.peek() != EOF;

	return !fail1 && !fail2;
}

bool User::getValidPos(int& x, int& y)
{
	std::string inputLine;
	std::getline(std::cin, inputLine);

	whitespaceCleaner(inputLine);

	std::stringstream inputStream(inputLine);

	bool fail1 = (inputStream >> x).fail();
	bool fail2 = (inputStream >> y).fail();
	bool fail3 = inputStream.peek() != EOF;

	if (fail1 || fail2 || fail3)
	{
		std::cout << "Please check your input, you may have written a wrong amount or accidentally entered an invalid character\n";
		std::cout << "Also make sure to leave a space between each number\n\n";
	}

	return !fail1 && !fail2 && !fail3;
}

bool User::getValidDir(int& d)
{
	std::string inputLine;
	std::getline(std::cin, inputLine);

	whitespaceCleaner(inputLine);

	std::stringstream inputStream(inputLine);

	bool fail1 = (inputStream >> d).fail();
	bool fail2 = !(d == 1 || d == 0);
	bool fail3 = inputStream.peek() != EOF;

	if (fail2)
	{
		std::cout << "Number out of bounds, posible inputs are 1 or 0\n";
	}

	return !fail1 && !fail2 && !fail3;
}


void User::placeMines()
{
	int total = 0;
	int radius = 1;

	std::cout << "Write down where you want to place your mines, in order to do so you will first need to input two coordinates. Example : 0 1" << std::endl;

	while (total < 5)
	{
		int posX = 0;
		int posY = 0;
		bool input = true;

		do
		{
			if (posX > 9 || posY > 9)
				std::cout << "input value too high\n";
			if(posX < 0 || posY < 0)
				std::cout << "input value too low\n";

			std::cout << "Pos " << total + 1 << " > ";
			input = getValidPos(posX, posY);

		} while (!input || posX > 9 || posY > 9 || posX < 0 || posY < 0);

		if (playArea.getPropId(posX, posY) == PropsType::WATER)
		{
			mines[total] = new Mine(posX, posY, this);
			playArea.changeProp(posX, posY, mines[total]);
			total++;
		}
		else {
			std::cout << "That spot is already taken by another prop, please try again" << std::endl;
		}

	}

};

void User::placeShip(int total)
{
	std::cout << "Write down where you want to place your ships, you need to input two coordinates which will determine the initial position. Example : 0 1" << std::endl;
	std::cout << "Once the initial position is checked, you will need to set up a direction: 0 (downwards), 1 (rightwards)" << std::endl;
	std::cout << "If any part of the ship collides with a bomb or is out of bounds, you will be requested to place it again" << std::endl;
		
	bool isComplete = false;

	do
	{
		int posX = 0;
		int posY = 0;

		bool input = true;

		int dir = 0;
		int length = total + 2;

		do
		{
			if (posX > 9 || posY > 9)
				std::cout << "input value too high\n";
			if (posX < 0 || posY < 0)
				std::cout << "input value too low\n";

			std::cout << "Pos " << total + 1 << " > ";
			input = getValidPos(posX, posY);
		} while (!input || posX > 9 || posY > 9 || posX < 0 || posY < 0);

		if (playArea.getPropId(posX, posY) == PropsType::WATER)
		{
			bool isValid = true;

			do
			{
				std::cout << "Direction > ";
				input = getValidDir(dir);

			} while (!input);

			if (dir == 0)
			{
				int i = 0;

				while (i < length)
				{
					if (playArea.getPropId(posX, posY + i) == PropsType::WATER)
					{
						i++;
					}

					else
					{
						isValid = false;
						break;
					}

				}
			}

			if (dir == 1)
			{
				int i = 0;

				while (i < length)
				{
					if (playArea.getPropId(posX + i, posY) == PropsType::WATER)
					{
						i++;
					}

					else
					{
						isValid = false;
						break;
					}
				}
			}

			if (isValid)
			{
				ships[total] = new Ship(length, dir, posX, posY, this);
				isComplete = true;
			}
			else
				std::cout << "One of the parts of the ship is colliding with another prop" << std::endl;

		}
		else
			std::cout << "That spot is already taken by another prop, please try again" << std::endl;

	} while (!isComplete);
	
}

PropsType User::identifyProp(int x, int y)
{
	return playArea.getPropId(x,y);
}

Coordinates User::move(PlayZone& enemBoard)
{
	std::cout << "Place state the position where you want to attack, remember to leave a space between each coordinate. (Example: 1 1)\n";

	int x = 0;
	int y = 0;
	bool valid = false;

	while (!valid || x > 9 || y > 9 || x < 0 || y < 0)
	{
		if (x > 9 || y > 9)
			std::cout << "position out of bounds!!\n";

		valid = getValidPos(x, y);
	};

	Coordinates newCoord;
	newCoord.setPos(x, y);

	enemBoard.getProp(x, y)->hit(playArea);

	return newCoord;
};