#ifndef Coordinates_H
#define Coordinates_H
#include <iostream>

struct Coordinates
{
private:
	int posX;
	int posY;
public:
	int getPosY() {
		return posY;
	};
	int getPosX() {
		return posX;
	}
	void setPos(int x, int y) {
		posX = x;
		posY = y;
	};
};
#endif
