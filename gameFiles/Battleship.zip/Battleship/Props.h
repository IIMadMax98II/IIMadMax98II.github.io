#ifndef Props_H
#define Props_H
#include<iostream>
#include "Coordinates.h"

class PlayZone;
class Player;

enum class PropsType
{
	WATER = 0,
	SHIP,
	MINE,
};

class Props {
protected:
	PropsType id;
	Coordinates position;
public:
	Props();
	virtual void place(int x, int y, PlayZone& board);
	virtual PropsType hit(PlayZone& enemBoard) = 0;
	virtual PropsType getId();
};

class ShipPart : public Props
{
private:
	bool isFunctional;
public:
	ShipPart();
	bool giveStatus();
	void setStatus(bool status);
	PropsType hit(PlayZone& enemBoard);
};

class Mine : public Props {
protected:
	Player* owner;
	bool isActive;
public:
	Mine(int x, int y, Player* self);
	PropsType hit(PlayZone& enemBoard);
};

class Water : public Props {
public:
	Water(int x, int y);
	PropsType hit(PlayZone& enemBoard);
};

class Ship
{
private:
	Player* owner;
	bool isDestroyed;
	int length;
	int totalDamage;
protected:
	ShipPart* parts;
public:
	Ship(int l, int dir, int posX, int posY, Player* owner);
	bool getIsDestroyed();
	int getTotalDamage();
	int getLength();
};



#endif
