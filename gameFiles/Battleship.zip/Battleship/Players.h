#ifndef Players_H
#define Players_H
#include <iostream>
#include <vector>
#include "Board.h"
#include "Coordinates.h"
#include "Visitor.h"
#include "Window.h"
#include "sstream"

class SelectiveGuesses
{
protected:
	std::vector<Coordinates> betterGuesses;
	Coordinates lastHit;
public:
	SelectiveGuesses();
	bool isEmpty();
	void setLastHit(Coordinates c);
	void addGuess(int x, int y);
	Coordinates popGuess();
	void adaptGuesses(int currentGuess, Coordinates guesses[]);
	void adaptPreciseGuesses(int currentGuess, Coordinates guesses[], int partsLeft) {};


};

class Player
{
protected:
	PlayZone playArea;
	Ship* ships[5];
	Mine* mines[5];
public:
	Player();
	virtual bool checkShipDestroyed(int x);
	virtual void placeMines() = 0;
	virtual void placeShip(int i) = 0;
	virtual int getSmallestShip() const;
	virtual int getDamageQuantity(int size) const;
	virtual Coordinates move(PlayZone& enemBoard) = 0;
	virtual PropsType identifyProp(int x, int y) = 0;
	virtual PlayZone& getPlayArea();
};

class User : public Player, public Window
{
private:
	std::string name;
public:
	User();
	~User();
	void setName();
	std::string getName();
	bool getValidName(std::string& name);
	void placeMines();
	void placeShip(int i);
	bool getValidPos(int& x, int& y);
	bool getValidDir(int& d);
	Coordinates move(PlayZone& enemBoard);
	PropsType identifyProp(int x, int y);
	void accept(Visitor* ai) override;
};

class AI : public Player, public Visitor
{
protected:
	Coordinates guesses[100];
	int currentGuess;
public:
	AI();
	~AI();
	void placeProps();
	void placeMines();
	void placeShips();
	void placeShip(int i);
	void shuffleGuesses();
	PropsType identifyProp(int x, int y);
	virtual Coordinates move(PlayZone& enemBoard);
	virtual void updateDamageQuantity(const Window* player, const int total) override {};
	virtual void updateSmallest(const Window* player, const int total) override {};
};

class Easy : public AI
{
public:
	Easy();
	Coordinates move(PlayZone& enemBoard);
};


class Intermediate : public AI
{
private:
	SelectiveGuesses betterGuesses;
public:
	Intermediate();
	Coordinates move(PlayZone& enemBoard);
};


class Hard : public AI 
{
private:
	int smallestShip;
	int partsLeft;
	SelectiveGuesses betterGuesses;
public:
	Hard();
	Coordinates move(PlayZone& enemBoard);
	void updateDamageQuantity(const Window* player, const int total);
	void updateSmallest(const Window* player, const int total);
};

#endif
