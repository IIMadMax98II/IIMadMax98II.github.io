#include "Visitor.h"
#include "Window.h"

void Visitor::updateDamageQuantity(const Window* player, const int total)
{
	//This will be overriden by the AI
}

void Visitor::updateSmallest(const Window* player, const int total)
{
	//This will be overriden by the AIs
}