#include "GameManager.h"

void GameManager::whitespaceCleaner(std::string& input)
{
	if (!input.empty())
	{
		int count = 0;
		int i = 0;
		while (input[i++] == ' ') { count++; }
		input.erase(0, count);
		i = input.length() - 1;
		count = 0;
		while (input[i--] == ' ') { count++; }
		input.erase(input.length() - count, count);
	}
}

bool GameManager::getValidInput(int& answer)
{
	std::string inputLine;
	std::getline(std::cin, inputLine);

	whitespaceCleaner(inputLine);

	std::stringstream inputStream(inputLine);

	bool fail1 = (inputStream >> answer).fail();
	bool fail2 = inputStream.peek() != EOF;

	return !fail1 && !fail2;
}

GameManager::GameManager()
{
	currentTurn = 0;
	difficulty = Difficulty::EASY;

	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			enemDisplay[i][j] = '.';
		}
	}

	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			playerDisplay[i][j] = '.';
		}
	}

	player = nullptr;
	machine = nullptr;
	isGameWon = false;
}

GameManager::~GameManager()
{
	delete player;
	delete machine;
}

void GameManager::initGame()
{
	createPlayers(selectDifficulty());
	printBoard();
	placeProps();
	
	do
	{
		startTurn();
		endTurn();
	} while (!isGameWon);

	endGame();
}

int GameManager::selectDifficulty() 
{
	int answer = 1;

	std::cout << "Please choose one of the following difficulties:" << std::endl;
	std::cout << "Easy - 0" << std::endl;
	std::cout << "Intermediate - 1" << std::endl;
	std::cout << "Hard - 2" << std::endl;
	std::cout << "Madman - 3" << std::endl;
	std::cout << "Wrong input type will set difficulty to Easy" << std::endl;
	do 
	{
		if (answer > 3 || answer < 0)
			std::cout << "Wrong input, number out of range" << std::endl;
		getValidInput(answer);
	} while (answer > 3 || answer < 0);

	return answer;
}

void GameManager::createPlayers(int n)
{
	player = new User();
	player->setName();

	switch (n)
	{
		case 0:
			machine = new Easy();
			difficulty = Difficulty::EASY;
			break;
		case 1:
			machine = new Intermediate();
			difficulty = Difficulty::INTERMEDIATE;
			break;
		case 2: 
			machine = new Hard();
			difficulty = Difficulty::HARD;
			break;
		case 3:
			machine = new Hard();
			difficulty = Difficulty::MADMAN;
			break;
		default:
			machine = new Easy();
			difficulty = Difficulty::EASY;
			break;
	}

	machine->shuffleGuesses();

}

void GameManager::printBoard()
{
	std::cout << "	==== Player Board ====" << std::endl;
	for (int i = 0; i < 10; i++)
	{
		if (i == 0)
			std::cout << "    0   1   2   3   4   5   6   7   8   9" << std::endl;
	

		std::cout << i << " ";

		for (int j = 0; j < 10; j++)
		{
			if (j == 0)
				std::cout << "| ";

			std::cout << playerDisplay[i][j] << " | ";
		}
		std::cout << std::endl;

	}

	if (!(difficulty == Difficulty::MADMAN))
	{
		std::cout << "	==== Guesses Board ====" << std::endl;

		for (int i = 0; i < 10; i++)
		{

			if (i == 0)
				std::cout << "    0   1   2   3   4   5   6   7   8   9" << std::endl;


			std::cout << i << " ";

			for (int j = 0; j < 10; j++)
			{
				if (j == 0)
					std::cout << "| ";
				std::cout << enemDisplay[i][j] << " | ";
			}
			std::cout << std::endl;
		}
	}
	
}

void GameManager::placeProps()
{
	player->placeMines();
	updateWholeBoard();
	printBoard();

	//Just make sure to update the board each time the player places a ship
	for (int i = 0; i < 5; i++)
	{
		player->placeShip(i);
		updateWholeBoard();
		printBoard();
	}

	machine->placeProps();
}

void GameManager::changeTurns()
{
	if (currentTurn == 0)
		currentTurn = 1;
	else
		currentTurn = 0;
}

void GameManager::startTurn()
{
	Coordinates result;
	currentTurn == 0 ? result = player->move(machine->getPlayArea()) : result = machine->move(player->getPlayArea());

	if (currentTurn == 0)
	{
		updateBoard(result.getPosX(), result.getPosY(), machine->identifyProp(result.getPosX(), result.getPosY()));
		printBoard();
	}
	else
	{
		updateBoard(result.getPosX(), result.getPosY(), player->identifyProp(result.getPosX(), result.getPosY()));
		printBoard();
	}
}

void GameManager::updateBoard(int x, int y, PropsType id)
{
	if (currentTurn == 0)
	{
		switch (id)
		{
		case PropsType::WATER:
			enemDisplay[y][x] = '_';
			break;
		case PropsType::SHIP:
			enemDisplay[y][x] = 'X';
			break;
		case PropsType::MINE:
			enemDisplay[y][x] = '!';
			playerDisplay[y][x] = '!';
			updateExplosionEffect(x, y, currentTurn);

			break;
		}
	}
	else {
		switch (id)
		{
		case PropsType::WATER:
			playerDisplay[y][x] = '_';
			break;
		case PropsType::SHIP:
			playerDisplay[y][x] = 'X';
			break;
		case PropsType::MINE:
			enemDisplay[y][x] = '!';
			playerDisplay[y][x] = '!';
			updateExplosionEffect(x, y, currentTurn);

			break;
		}
	}
}

void GameManager::updateWholeBoard()
{
	PropsType id = PropsType::WATER;

	for (int x = 0; x < 10; x++)
	{
		for (int y = 0; y < 10; y++)
		{
			id = player->identifyProp(x, y);

			if (id == PropsType::SHIP)
				playerDisplay[y][x] = 'S';
			if (id == PropsType::MINE)
				playerDisplay[y][x] = '+';
		}
	}
}

void GameManager::endTurn()
{
	changeTurns();
	checkGameStatus();
	player->accept(machine);
}

void GameManager::checkGameStatus()
{
	bool isItOver = true;
	int x = 0;
	int looser = 0; // 0 = player, 1 = AI

	while(x < 5)
	{
		if (!player->checkShipDestroyed(x))
		{
			isItOver = false;
			break;
		}
		else
			x++;
	}

	if (!isItOver)
	{
		isItOver = true;

		while (x < 5)
		{
			if (!machine->checkShipDestroyed(x))
			{
				isItOver = false;
				break;
			}
			else
			{
				std::cout << "Destroyed: " << x << std::endl;
				x++;
			}
			
				
		}

		if (isItOver)
			looser = 1;
			
	}
	else
		looser = 0;

	if (isItOver)
	{
		isGameWon = true;
		
		if (looser == 0)
			std::cout << "AI wins, humanity has been defeated !!" << std::endl;
		else
			std::cout << "Congratulations " << player->getName() << " you have defeated the machine, you should be proud" << std::endl;
	}
		
}

void GameManager::endGame()
{
	std::cout << "Thank you for playing, we will see you next time" << std::endl;
}

void GameManager::updateExplosionEffect(int x, int y, int player)
{
	if (player == 0) // is it the User:
	{
		if (x == 9)
			playerDisplay[y][x - 1] = '!';
		else if (x == 0)
			playerDisplay[y][x + 1] = '!';
		else
		{
			playerDisplay[y][x - 1] = '!';
			playerDisplay[y][x + 1] = '!';
		}

		if (y == 9)
			playerDisplay[y - 1][x] = '!';
		else if (y == 0)
			playerDisplay[y + 1][x] = '!';
		else
		{
			playerDisplay[y - 1][x] = '!';
			playerDisplay[y + 1][x] = '!';
		}
	}
	else
	{
		if (x == 9)
			enemDisplay[y][x - 1] = '!';
		else if (x == 0)
			enemDisplay[y][x + 1] = '!';
		else
		{
			enemDisplay[y][x - 1] = '!';
			enemDisplay[y][x + 1] = '!';
		}

		if (y == 9)
			enemDisplay[y - 1][x] = '!';
		else if (y == 0)
			enemDisplay[y + 1][x] = '!';
		else
		{
			enemDisplay[y - 1][x] = '!';
			enemDisplay[y + 1][x] = '!';
		}
	}
}