#include "Players.h"

Intermediate::Intermediate()
{
	betterGuesses = SelectiveGuesses();
}

Coordinates Intermediate::move(PlayZone& enemBoard)
{

	if (betterGuesses.isEmpty())
	{
		Coordinates tempHit = AI::move(enemBoard);
		betterGuesses.setLastHit(tempHit);

		
		if (enemBoard.getPropId(tempHit.getPosX(), tempHit.getPosY()) == PropsType::SHIP)
			betterGuesses.adaptGuesses(currentGuess, guesses);

		return tempHit;
	}
	else
	{
		Coordinates tempGuess = betterGuesses.popGuess();
		Coordinates tempGuess2 = guesses[currentGuess];

		int i = currentGuess;

		while (i < 100)
		{
			if (guesses[i].getPosX() == tempGuess.getPosX() && guesses[i].getPosY() == tempGuess.getPosY()) // if gues[i] == tempGuess : do ...
			{
				guesses[currentGuess] = guesses[i];
				guesses[i] = tempGuess2;
				
				break;
			}

			i++;
		}

		enemBoard.getProp(tempGuess.getPosX(), tempGuess.getPosY())->hit(playArea);
		betterGuesses.setLastHit(tempGuess);

		if (enemBoard.getPropId(tempGuess.getPosX(), tempGuess.getPosY()) == PropsType::SHIP)
			betterGuesses.adaptGuesses(currentGuess, guesses);

		currentGuess++;
		return tempGuess;
	}
}
