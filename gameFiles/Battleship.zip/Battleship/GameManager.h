#ifndef GM_H
#define GM_H
#include "Players.h"
#include <string>
#include <sstream>

enum class Difficulty
{
	EASY = 0,
	INTERMEDIATE,
	HARD,
	MADMAN,
};

class GameManager
{
private:
	User* player;
	AI* machine;
	int currentTurn;
	char enemDisplay[10][10];
	char playerDisplay[10][10];
	Difficulty difficulty;
	bool isGameWon;
public:
	GameManager();
	~GameManager();
	void initGame();
	int selectDifficulty();
	void createPlayers(int n);
	void placeProps();
	void changeTurns();
	void startTurn();
	void endTurn();
	void updateWholeBoard();
	void updateBoard(int x, int y, PropsType id);
	void updateExplosionEffect(int x, int y, int player);
	void printBoard();
	void checkGameStatus();
	void endGame();
	void whitespaceCleaner(std::string& input);
	bool getValidInput(int& answer);
};
#endif

