#include "Players.h"

Easy::Easy()
{
	//Nothing needed yet
}

Coordinates Easy::move(PlayZone& enemBoard)
{
	return AI::move(enemBoard);
}