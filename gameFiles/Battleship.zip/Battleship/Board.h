#ifndef Board_H
#define Board_H
#include <iostream>
#include "Props.h"

class PlayZone
{	
protected:
	Props* board[10][10];
public:
	PlayZone();
	Props* getProp(int x, int y);
	void changeProp(int x, int y, Props* newProp);
	PropsType getPropId(int x, int y);
};
#endif
