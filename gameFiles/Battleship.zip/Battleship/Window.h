#ifndef Window_H
#define Window_H

class Visitor;

class Window
{
public:
	virtual void accept(Visitor* ai) = 0;
};


#endif
