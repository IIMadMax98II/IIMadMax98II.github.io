#include "Props.h"
#include "Board.h"

Props::Props()
{
	id = PropsType::WATER;
	position = Coordinates();
}

void Props::place(int x, int y, PlayZone& board)
{
	position.setPos(x, y);
	board.changeProp(x, y,this);
}

PropsType Props::getId()
{
	return id;
}

Water::Water(int x, int y)
{
	position.setPos(x, y);
	id = PropsType::WATER;
}

PropsType Water::hit(PlayZone& enemBoard)
{
	std::cout << "SPLASH!! you missile impacted on the water\n";
	return id;
}