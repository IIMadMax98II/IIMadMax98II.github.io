#include "Players.h"

AI::AI()
{
	int i = 0;
	currentGuess = 0;

	for (int x = 0; x < 10; x++)
	{
		for (int y = 0; y < 10; y++)
		{
			guesses[i++].setPos(x, y);
		}
	}
}

AI::~AI()
{
	for (int i = 0; i < 5; i++)
	{
		delete mines[i];
		delete ships[i];
	}
}

PropsType AI::identifyProp(int x, int y)
{
	return playArea.getPropId(x, y);
}

void AI::placeProps()
{
	placeShips();
	placeMines();
}

void AI::placeMines()
{
	int randX;
	int randY;
	int radius = 1;

	for (int i = 0; i < 5; i++)
	{
		do 
		{
			randX = rand() % 10;
			randY = rand() % 10;
		} while (playArea.getPropId(randX,randY) != PropsType::WATER);

		mines[i] = new Mine(randX, randY, this);
		playArea.changeProp(randX, randY, mines[i]);
	}
};

void AI::placeShip(int x)
{
	int randX;
	int randY;
	int randDir;
	int length;
	int i = 0;
	bool isValid;

	while (i < 1)
	{
		isValid = true;

		do
		{
			randX = rand() % 10;
			randY = rand() % 10;
		} while (playArea.getPropId(randX, randY) != PropsType::WATER);

		randDir = rand() % 2;
		length = x + 2;

		//Now we check that the ships are placed inside the array:

		if (randDir == 0) // if the direction is vertical
		{
			if (randY + length < 10)// if the length is smaller than the maximum array capacity
			{
				int currentLength = 0;

				while (currentLength < length)
				{
					if (playArea.getPropId(randX, randY + currentLength) == PropsType::WATER)
					{
						currentLength++;
					}
					else
					{
						isValid = false;
						break;
					}

				}
			}
			else
				isValid = false;
		}
		else
		{
			if (randX + length < 10)// if the length is smaller than the maximum array capacity
			{
				int currentLength = 0;

				while (currentLength < length)
				{
					if (playArea.getPropId(randX + currentLength, randY) == PropsType::WATER)
					{
						currentLength++;
					}

					else
					{
						isValid = false;
						break;
					}

				}
			}
			else
				isValid = false;
		}

		if (isValid)
		{
			ships[x] = new Ship(length, randDir, randX, randY, this); // we place the ship
			i++;
		}
	}
}

void AI::placeShips()
{
	for (int i = 0; i < 5; i++)
		placeShip(i);
};

Coordinates AI::move(PlayZone& enemBoard) 
{
	
	Coordinates attCoord;
	attCoord.setPos(guesses[currentGuess].getPosX(), guesses[currentGuess].getPosY());
	enemBoard.getProp(guesses[currentGuess].getPosX(), guesses[currentGuess].getPosY())->hit(playArea);
	currentGuess++;

	return attCoord;
}

void AI::shuffleGuesses()
{
	Coordinates temp;
	int randIndex = 0;

	for (int i = 0; i < 100; i++)
	{
		randIndex = rand() % 99;
		temp = guesses[i];
		guesses[i] = guesses[randIndex];
		guesses[randIndex] = temp;
	}
}
