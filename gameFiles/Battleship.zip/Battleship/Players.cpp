#include "Players.h"

Player::Player()
{
	for (int i = 0; i < 5; i++)
	{
		ships[i] = nullptr;
		mines[i] = nullptr;
	}
}

PlayZone& Player::getPlayArea()
{
	return playArea;
}

bool Player::checkShipDestroyed(int x)
{
	return ships[x]->getIsDestroyed();
}

int Player::getSmallestShip() const 
{
	int i = 0;

	while (i < 5)
	{
		if (!ships[i]->getIsDestroyed())
		{
			return i + 2;
		}
		else
			i++;
	}

	return -1;
}

int Player::getDamageQuantity(int size) const
{
	int i = 0;
	int damage = 0;

	while (i < 5)
	{
		if (ships[i]->getLength() == size)
		{
			damage = ships[i]->getTotalDamage();
			break;
		}

		i++;
	}

	return damage;
}

