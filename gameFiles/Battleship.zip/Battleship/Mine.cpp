#include "Props.h"
#include "Board.h"
#include "Players.h"

Mine::Mine(int x, int y, Player* self)
{
	isActive = true;
	owner = self;
	id = PropsType::MINE;
	position.setPos(x, y);
}

PropsType Mine::hit(PlayZone& enemBoard)
{
	if (isActive)
	{

		isActive = false;
		std::cout << "BOOOM!!!! Explosive triggered\n";

		enemBoard.getProp(position.getPosX(), position.getPosY())->hit(owner->getPlayArea());

		if (position.getPosX() == 9)
			enemBoard.getProp(position.getPosX() - 1, position.getPosY())->hit(owner->getPlayArea());
				
			
		else if (position.getPosX() == 0)
			enemBoard.getProp(position.getPosX() + 1, position.getPosY())->hit(owner->getPlayArea());
			
		else
		{
			enemBoard.getProp(position.getPosX() + 1, position.getPosY())->hit(owner->getPlayArea());
			enemBoard.getProp(position.getPosX() - 1, position.getPosY())->hit(owner->getPlayArea());
		}

		if (position.getPosY() == 9)
			enemBoard.getProp(position.getPosX(), position.getPosY() - 1)->hit(owner->getPlayArea());
			
		else if (position.getPosY() == 0)
			enemBoard.getProp(position.getPosX(), position.getPosY() + 1)->hit(owner->getPlayArea());
			
		else
		{
			enemBoard.getProp(position.getPosX(), position.getPosY() + 1)->hit(owner->getPlayArea());
			enemBoard.getProp(position.getPosX(), position.getPosY() - 1)->hit(owner->getPlayArea());
		}
	}

	return id;
}