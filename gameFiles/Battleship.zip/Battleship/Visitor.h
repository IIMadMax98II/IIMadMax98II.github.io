#ifndef Visitor_H
#define Visitor_H
#include <iostream>

class Window;

class Visitor {
public:
	virtual void updateSmallest(const Window* player, const int total) = 0;
	virtual void updateDamageQuantity(const Window* player, const int total) = 0;
};
#endif