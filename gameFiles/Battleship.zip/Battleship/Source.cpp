#include "GameManager.h"

int main()
{
	GameManager gm;
	gm.initGame();

	return 0;
}